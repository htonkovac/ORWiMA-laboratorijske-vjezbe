package tn.hrv.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private TextView mTextView;
    private EditText mEditText;
    private Button mFetchButton;
    Call<List<User>> call;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextView = findViewById(R.id.tvUserInfo);
        mEditText = findViewById(R.id.etNumber);
        mFetchButton = findViewById(R.id.btnFetch);
        setUpListeners();
        setUpApiCall();
    }

    private void setUpListeners() {
        mFetchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchUser();
            }
        });
    }

    private void fetchUser() {
        Call<User> call = NetworkUtils.getsAPIInterface().getUser(mEditText.getText().toString());
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful() && response.body() != null) {
                    mTextView.setText(parseUser(response.body()));
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {

            }
        });
    }

    private void setUpApiCall() {
        call = NetworkUtils.getsAPIInterface().getUsers();
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    showUsers(response.body());
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Toast.makeText(MainActivity.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showUsers(List<User> body) {
        StringBuilder stringBuilder = new StringBuilder();
        for (User user : body) {
            stringBuilder.append(parseUser(user));
        }
        mTextView.setText(stringBuilder.toString());
    }

    private StringBuilder parseUser(User user) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(user.getName()).append("\n")
                .append(user.getAddress().getStreet()).append("\n")
                .append(user.getAddress().getSuite()).append("\n")
                .append(user.getAddress().getZipcode()).append("\n\n");
        return stringBuilder;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (call != null) {
            call.cancel();
        }
    }
}
